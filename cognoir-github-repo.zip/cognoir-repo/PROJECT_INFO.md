# Cognoir Project Info

## Project Overview
Cognoir is a modern, production-ready authentication system built with React and TypeScript.

## Quick Stats
- **Language:** TypeScript
- **Framework:** React 18
- **Build Tool:** Vite
- **Package Manager:** npm

## Key Features
- Secure authentication
- User session management
- Password validation
- Responsive design
- Full TypeScript support

## File Structure
```
src/
├── components/     - React UI components
├── contexts/       - React context providers
├── types/          - TypeScript type definitions
├── stores/         - State management
├── App.tsx         - Main app component
└── main.tsx        - Entry point

public/            - Static assets

docs/              - Documentation files

tests/             - Test files

.github/workflows/ - CI/CD pipelines
```

## Getting Started Commands
```bash
npm install        # Install dependencies
npm run dev        # Start development server
npm run build      # Build for production
npm run lint       # Run linter
npm run type-check # Type check
```

## Deployment
The built files in `dist/` can be deployed to:
- Vercel
- Netlify
- GitHub Pages
- Any static hosting service

## Configuration Files
- `vite.config.ts` - Vite bundler configuration
- `tsconfig.json` - TypeScript configuration
- `package.json` - Project metadata and dependencies
- `.eslintrc.cjs` - Linting rules
- `.prettierrc` - Code formatting rules
